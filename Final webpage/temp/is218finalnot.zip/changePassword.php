<!DOCTYPE html>
<html>

<head>
  <title>Password Change</title>

</head>

<body>
  <h3 align="center">CHANGE PASSWORD</h3>
  <div><?php if (isset($message)) {
          echo $message;
        } ?></div>
  <form method="post" action="" align="center">
    Current email:<br>
    <input type="text" name="email"><span id="email" class="required"></span>
    <br>
    Current Password:<br>
    <input type="password" name="currentPassword"><span id="currentPassword" class="required"></span>
    <br>
    New Password:<br>
    <input type="password" name="newPassword"><span id="newPassword" class="required"></span>
    <br>
    Confirm Password:<br>
    <input type="password" name="confirmPassword"><span id="confirmPassword" class="required"></span>
    <br><br>
    <input type="submit">
  </form>
  <br>
  <br>
</body>

</html>
<?php
if (isset($_POST["newPassword"])) {
  session_start();
  $email = $_POST["email"]; /* Current email */
  $currentPassword = $_POST["currentPassword"];/* current user Password */
  $newPassword = $_POST["newPassword"];/* new user Password */
  $confirmPassword = $_POST["confirmPassword"];/* confirm new user Password */
  // YOU MUST CREATE FILE CALLED configure.php and have following code inside
  /*
    <?php
    $hostname = "sql1.njit.edu"     ; 	  // or "sql2.njit.edu"   OR "sql1.njit.edu"
    $username = "username" ;
    $project  = "database" ;
    $password = "database password" ;
    ?>
*/
require("./configure.php");
$connection_string = "mysql:host=$hostname;dbname=$project;charset=utf8mb4";

function password_validator($password)
{
$error = "";

if (strlen($password) < 8) { $error .="Password too short!
      " ; } if (strlen($password)> 29) {
  $error .= "Password too long!
  ";
  }
  if (!preg_match("#[0-9]+#", $password)) {
  $error .= "Password must include at least one number!
  ";
  }
  if (!preg_match("#[a-z]+#", $password)) {
  $error .= "Password must include at least one letter!
  ";
  }
  if (!preg_match("#[A-Z]+#", $password)) {
  $error .= "Password must include at least one CAPS!
  ";
  }
  return $error;
  }

  try {
  //setup db
  $db = new PDO($connection_string, $username, $password);
  $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  //check if email already exists
  $stmt = $db->prepare("SELECT * FROM users where email=:email");
  $stmt->execute(["email" => $email]);
  // and somewhere later:
  $user = $stmt->fetch();
  if (!$user) {
  echo "No user found. Please sign up before updating your password<br>";
  exit();
  }
  if ($result = password_validator($newPassword)) {
  echo $result;
  exit();
  }
  $old_hash = $user["password"];
  if (!password_verify($currentPassword, $old_hash)) {
  echo "Current Password does not match. Please try again.";
  exit();
  }
  if ($newPassword !== $confirmPassword) {
  echo "New and confirm password does not match. Try again.";
  exit();
  }
  if(Hash::check($newPassword, $old_hash)){
  	exit('Sorry can\'t use the same password twice');
  }
  $sql = "UPDATE users SET password=:password where email=:email";
  $stmt = $db->prepare($sql);
  $stmt->execute(["password" => password_hash($newPassword, PASSWORD_BCRYPT), "email" => $email]);
  if ($stmt) {
  echo "Password successfully updated.";
  exit();
  } else {
  echo "Something went wrong. Please try again.";
  exit();
  }
  } catch (Exception $e) {
  echo $e->getMessage();
  exit();
  }
  }
  ?>