<!DOCTYPE html>
<html>

<head>
  <title>Username Change</title>

</head>

<body>
  <input type="button" class="btn btn-lg btn-success" onclick="location.href='Login.php';" value="Home" />
  <h3 align="center">CHANGE USERNAME</h3>
  <form method="post" action="" align="center">
    New Username:<br>
    <input type="text" name="newUsername"><span id="newUsername" class="required"></span>
    <br>
    Current email:<br>
    <input type="text" name="email"><span id="email" class="required"></span>
    <br>
    Password:<br>
    <input type="password" name="password"><span id="password" class="required"></span>
    <br><br>
    <input type="submit">
  </form>
  <br>
  <br>
</body>

</html>
<?php
if (isset($_POST["password"])) {
  session_start();
  $newUsername = $_POST["newUsername"];/* new username */
  $email = $_POST["email"]; /* Current email */
  $userPassword = $_POST["password"];/* confirm user Password */
  require("config.php");
  $connection_string = "mysql:host=$dbhost;dbname=$dbdatabase;charset=utf8mb4";

  $error = "";
  function validate_username($username,&$error){
      if(preg_match("/[@=_'\-+,<>]/",$username)){
          $error.= "Username contains invalid characters.";
          return 0;
      }else if (strpos($username,"..")){
          $error.="Username Can not contain consecutive periods.";
          return 0;
      }else if (strpos($username,".",-1)){
          $error.="Username Can not end with a period.";
          return 0;
      }
      return 1;
  }

  try {
    //check if the new username meets the requirements
    if(!validate_username($newUsername,$error)){
        echo $error;
        exit();
    }
    //setup db
    $db = new PDO($connection_string, $dbuser, $dbpass);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //check if email already exists
    $stmt = $db->prepare("SELECT * FROM users where username=:username");
    $stmt->execute(["username" => $newUsername]);
    $user = $stmt->fetch();
    if ($user) {
      echo "Username already exist so try new unique username.<br>";
      exit();
    }
    $stmt = $db->prepare("SELECT * FROM users where email=:email");
    $stmt->execute(["email" => $email]);
    $user = $stmt->fetch();
    $password_hash = $user["password"];
    if (!password_verify($userPassword, $password_hash)) {
      echo "Password is incorrect.";
      exit();
    }
    $sql = "UPDATE users SET username=:username where email=:email";
    $stmt = $db->prepare($sql);
    $stmt->execute(["username" => $newUsername, "email" => $email]);
    if ($stmt) {
      echo "Username successfully updated.";
      exit();
    } else {
      echo "Something went wrong. Please try again.";
      exit();
    }
  } catch (Exception $e) {
    echo $e->getMessage();
    exit();
  }
}
  ?>
