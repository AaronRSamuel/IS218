<?php
session_start();
echo $_SESSION['id'];
?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>
            IS 218 Calendar
        </title>
    </head>
    <header>
        <button onclick="location.href = 'signout.php';" name="logout">Logout</button>
        <button onclick="location.href = 'changeUsername.php';" name="profile">Change Username</button>
        <button onclick="location.href = 'changePassword.php';" name="profile">Change Password</button>
    </header>
    <body>

    <input type="submit" class = "button" name="display" value ="display">
    <?php
    if(array_key_exists('display',$_POST)){
        DisplayTasks();
    }
    ?>
    <h2>
        Create an Event
    </h2>
    <div id="createevent"><form method ="POST">
            Event: <input type="text" name="eventname" value = "Enter Name here"><br>
            Date: <input type="datetime-local" name="eventdate"><br>
            Description: <input type="text" name="desc" value="Enter description here"><br>
            Urgency: <select name="urgency" id="prio">
                <option value="normal">normal</option>
                <option value="important">important</option>
                <option value="veryimportant">veryimportant</option>
            </select><br>
            <input type="submit" value="Create" name="createButton">
        </form>
    </div>

    <h2>
        Modify an Event
    </h2>
    <div id="Modifyevent"><form method ="post">
            Event ID: <input type="int" name="eventID"><br>
            Event: <input type="text" name="eventname" value = "Enter Name here"><br>
            Date: <input type="datetime-local" name="eventdate"><br>
            Description: <input type="text" name="desc" value="Enter description here"><br>
            Urgency: <select name="urgency" id="prio">
                <option value="normal">Normal</option>
                <option value="important">Important</option>
                <option value="veryimportant">Very important</option>
            </select><br>
            <input type="submit" value="Edit" name="modifyButton">
        </form>
    </div>
    </body>
    </html>
    <h2>
        Delete an Event
    </h2>
    <div id="Deleteevent"><form method ="post">
            Event ID: <input type="int" name="eventID"><br>
            <input type="submit" value="Delete" name="deleteButton">
        </form>
    </div>
    <h2>
        Update the status of an event
    </h2>
    <div id="StateUpdate"><form method ="post">
            Event ID: <input type="int" name="eventID"><br>
            <label for="state">State:</label>
            <input type ="checkbox" id="state" name="statebox"><br>
            <input type="submit" value="Update" name="stateButton">
        </form>
    </div>

    </body>
    </html>
<?php

function DisplayTasks() {
    DisplayStates();
    $userid= $_SESSION['id'];
    try {
        require("config.php");
        $connection_string = "mysql:host=$dbhost;dbname=$dbdatabase;charset=utf8mb4";
        $conn = new PDO($connection_string, $dbuser, $dbpass);
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    catch(PDOException $e)
    {
        echo "Connection failed: " . $e->getMessage();
    }
    echo "incomplete tasks:";
    $userid= $_SESSION['id'];
    $urgency= 'veryimportant';
    $query = $conn->prepare("SELECT * FROM `events` WHERE userid = :userid AND urgency = :urgency AND status = :status");
    $params = array(":userid"=>$userid, ":urgency"=>$urgency, ":status"=>00);
    $query->execute($params);
    $result = $query->fetchAll();
    $query->closeCursor();
    $start = date_create("Y.m.d h:i:sa");
    echo "<table>";
    foreach($result as $row){
        date_default_timezone_set('America/Los_Angeles');
        $start = new DateTime('now');
        $end = date_create($row['evt_start']);
        $diff = date_diff($start, $end);       
        echo "<tr>";
        echo "<td>".$row['evt_id']."</td>";
        echo "<td>".$row['evt_start']."</td>";
        echo "<td>".$row['evt_end']."</td>";
        echo "<td>".$row['evt_text']."</td>";
        echo "<td>".$row['urgency']."</td>";
        echo "<td>".$row['description']."</td>";
        echo "<td>".$diff->format("%R%a days")."</td>";
        echo "</tr>";
    }
    echo "</table>";
    $userid=$_SESSION['id'];
    $important = 'important';
    $query = $conn->prepare("SELECT * FROM `events` WHERE userid = :userid AND urgency = :urgency AND status = :status");
    $params = array(":userid"=>$userid, ":urgency"=>$important, ":status"=>00);
    $query->execute($params);
    $result = $query->fetchAll();
    $query->closeCursor();
    $start = date_create("Y.m.d h:i:sa");
    $end = date_create('evt_start');
    echo "<table>";
    foreach($result as $row){
        date_default_timezone_set('America/Los_Angeles');
        $start = new DateTime('now');
        $end = date_create($row['evt_start']);
        $diff = date_diff($start, $end);       
        echo "<tr>";
        echo "<td>".$row['evt_id']."</td>";
        echo "<td>".$row['evt_start']."</td>";
        echo "<td>".$row['evt_end']."</td>";
        echo "<td>".$row['evt_text']."</td>";
        echo "<td>".$row['urgency']."</td>";
        echo "<td>".$row['description']."</td>";
        echo "<td>".$diff->format("%R%a days")."</td>";
        echo "</tr>";
    }
    echo "</table>";
    $userid=$_SESSION['id'];
    $normal = 'normal';
    $query = $conn->prepare("SELECT * FROM `events` WHERE userid = :userid AND urgency = :urgency AND status = :status");
    $params = array(":userid"=>$userid, ":urgency"=>$normal, ":status"=>00);
    $query->execute($params);
    $result = $query->fetchAll();
    $query->closeCursor();

    $start = date_create("Y.m.d h:i:sa");
    $end = date_create('evt_start');
    echo "<table>";
    foreach($result as $row){
        date_default_timezone_set('America/Los_Angeles');
        $start = new DateTime('now');
        $end = date_create($row['evt_start']);
        $diff = date_diff($start, $end);       
        echo "<tr>";
        echo "<td>".$row['evt_id']."</td>";
        echo "<td>".$row['evt_start']."</td>";
        echo "<td>".$row['evt_end']."</td>";
        echo "<td>".$row['evt_text']."</td>";
        echo "<td>".$row['urgency']."</td>";
        echo "<td>".$row['description']."</td>";
        echo "<td>".$diff->format("%R%a days")."</td>";
        echo "</tr>";
    }
    echo "</table>";
    //Checked tasks
    echo "compleated tasks:";
    $urgency= 'veryimportant';
    $query = $conn->prepare("SELECT * FROM `events` WHERE userid = :userid AND urgency = :urgency AND status = :status");
    $params = array(":userid"=>$userid, ":urgency"=>$urgency, ":status"=>1);
    $query->execute($params);
    $result = $query->fetchAll();
    $query->closeCursor();
    $start = date_create("Y.m.d h:i:sa");
    echo "<table>";
    foreach($result as $row){
        date_default_timezone_set('America/Los_Angeles');
        $start = new DateTime('now');
        $end = date_create($row['evt_start']);
        $diff = date_diff($start, $end);       
        echo "<tr>";
        echo "<td>".$row['evt_id']."</td>";
        echo "<td>".$row['evt_start']."</td>";
        echo "<td>".$row['evt_end']."</td>";
        echo "<td>".$row['evt_text']."</td>";
        echo "<td>".$row['urgency']."</td>";
        echo "<td>".$row['description']."</td>";
        echo "<td>".$diff->format("%R%a days")."</td>";
        echo "</tr>";
    }
    echo "</table>";
    $userid=$_SESSION['id'];
    $important = 'important';
    $query = $conn->prepare("SELECT * FROM `events` WHERE userid = :userid AND urgency = :urgency AND status = :status");
    $params = array(":userid"=>$userid, ":urgency"=>$important, ":status"=>1);
    $query->execute($params);
    $result = $query->fetchAll();
    $query->closeCursor();
    $start = date_create("Y.m.d h:i:sa");
    $end = date_create('evt_start');
    echo "<table>";
    foreach($result as $row){
        date_default_timezone_set('America/Los_Angeles');
        $start = new DateTime('now');
        $end = date_create($row['evt_start']);
        $diff = date_diff($start, $end);       
        echo "<tr>";
        echo "<td>".$row['evt_id']."</td>";
        echo "<td>".$row['evt_start']."</td>";
        echo "<td>".$row['evt_end']."</td>";
        echo "<td>".$row['evt_text']."</td>";
        echo "<td>".$row['urgency']."</td>";
        echo "<td>".$row['description']."</td>";
        echo "<td>".$diff->format("%R%a days")."</td>";
        echo "</tr>";
    }
    echo "</table>";
    $userid=$_SESSION['id'];
    $normal = 'normal';
    $query = $conn->prepare("SELECT * FROM `events` WHERE userid = :userid AND urgency = :urgency AND status = :status");
    $params = array(":userid"=>$userid, ":urgency"=>$normal, ":status"=>1);
    $query->execute($params);
    $result = $query->fetchAll();
    $query->closeCursor();

    $start = date_create("Y.m.d h:i:sa");
    $end = date_create('evt_start');
    echo "<table>";
    foreach($result as $row){
        date_default_timezone_set('America/Los_Angeles');
        $start = new DateTime('now');
        $end = date_create($row['evt_start']);
        $diff = date_diff($start, $end);       
        echo "<tr>";
        echo "<td>".$row['evt_id']."</td>";
        echo "<td>".$row['evt_start']."</td>";
        echo "<td>".$row['evt_end']."</td>";
        echo "<td>".$row['evt_text']."</td>";
        echo "<td>".$row['urgency']."</td>";
        echo "<td>".$row['description']."</td>";
        echo "<td>".$diff->format("%R%a days")."</td>";
        echo "</tr>";
    }
    echo "</table>";
}
function DisplayStates(){
    require("config.php");
    $userid = $_SESSION['id'];
    $connection_string = "mysql:host=$dbhost;dbname=$dbdatabase;charset=utf8mb4";
    try {
        $conn = new PDO($connection_string, $dbuser, $dbpass);
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    }
    catch(PDOException $e)
    {
        echo "Connection failed: " . $e->getMessage();
    }
    $query = $conn->prepare("SELECT * FROM `events` WHERE userid= :userid");
    $params = array("userid"=>$userid);
    $query->execute($params);
    $res = $query->fetchAll();
    $complete = 0;
    $not = 0;
    foreach($res as $row){
      if($row['status']==00){
        $complete +=1;
      }
      else{
        $not +=1;
      }
    }
    echo "Completed Tasks: ".$complete."<br>";
    echo "Uncompleted Tasks: ".$not."<br>";

}
function CreateTask(){
    try{
        //echo "step1";
        require("config.php");
        $connection_string = "mysql:host=$dbhost;dbname=$dbdatabase;charset=utf8mb4";
        if(isset($_POST['eventdate']) && isset($_POST['eventname']) && isset($_POST['desc']) && isset($_POST['urgency'])){
            $eventdate = $_POST['eventdate'];
            $eventname = $_POST['eventname'];
            $desc = $_POST['desc'];
            $urgency = $_POST['urgency'];
            $userid = $_SESSION['id'];
        }
        else{
            echo"something not set";
            exit();
        }
    }
    catch(Exception $e){
        echo "idk: " . $e->getMessage();
    }
    //echo " step2";
    try {
        $conn = new PDO($connection_string, $dbuser, $dbpass);
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    catch(PDOException $e)
    {
        echo "Connection failed: " . $e->getMessage();
    }
    //echo " step3";
    try{
        $query = $conn->prepare("INSERT INTO `events` (evt_start, evt_text, urgency, description, userid) VALUES (:eventdate, :eventname, :urgency,:desc, :userid)");
        $params = array(":eventdate"=> $eventdate,":eventname"=> $eventname, ":desc"=> $desc, ":urgency"=> $urgency, ":userid"=> $userid);
        $query->execute($params);
    }
    catch(PDOException $e)
    {
        echo "SQL failed: " . $e->getMessage();
    }
}
function DeleteTask(){
    echo("step1");
    require("config.php");
    $connection_string = "mysql:host=$dbhost;dbname=$dbdatabase;charset=utf8mb4";
    if(isset($_POST['eventID'])){
        $evt_id = $_POST['eventID'];
    }
    else{
        exit();
    }
    try {
        $conn = new PDO($connection_string, $dbuser, $dbpass);
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    catch(PDOException $e)
    {
        echo "Connection failed: " . $e->getMessage();
    }
    echo("step2");
    try{
        $query = $conn->prepare("DELETE FROM `events` WHERE evt_id = :evt_id");
        $params = array(":evt_id"=>$evt_id);
        $query->execute($params);
    }
    catch(PDOException $e)
    {
        echo "Connection failed: " . $e->getMessage();
    }
}
function ModifyTask(){
    //echo "step1";
    require("config.php");
    $connection_string = "mysql:host=$dbhost;dbname=$dbdatabase;charset=utf8mb4";
    echo"step1.1";
    if(isset($_POST['eventID']) && isset($_POST['eventdate']) && isset($_POST['eventname']) && isset($_POST['desc']) && isset($_POST['urgency'])){
        $evt_id = $_POST['eventID'];
        $eventdate = $_POST['eventdate'];
        $eventname = $_POST['eventname'];
        $desc = $_POST['desc'];
        $urgency = $_POST['urgency'];
    }
    else{
        echo"wrong";
        exit();
    }
    //echo "step2";
    try {
        $conn = new PDO($connection_string, $dbuser, $dbpass);
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    }
    catch(PDOException $e)
    {
        echo "Connection failed: " . $e->getMessage();
    }
    //echo"step3";
    try{
        $query = $conn->prepare("UPDATE `events` SET evt_start = :eventdate, evt_text = :eventname, urgency = :urgency, description = :desc WHERE evt_id= :evt_id");
        $params = array(":eventdate"=> $eventdate,":eventname"=> $eventname, ":desc"=> $desc, ":urgency"=> $urgency, ":evt_id"=> $evt_id);
        $query->execute($params);
    }
    catch(PDOException $e){
        echo "SQL failed: " . $e->getMessage();
    }
}
function TaskStatus(){
    require("config.php");
    $connection_string = "mysql:host=$dbhost;dbname=$dbdatabase;charset=utf8mb4";
    if(isset($_POST['eventID'])){
        $evt_id = $_POST['eventID'];
    }
    else{
        echo "wrong";
        exit();
    }
    try {
        $conn = new PDO($connection_string, $dbuser, $dbpass);
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    }
    catch(PDOException $e)
    {
        echo "Connection failed: " . $e->getMessage();
    }
    //echo"step1";
    $query = $conn->prepare("SELECT * FROM `events` WHERE evt_id= :evt_id");
    $params = array(":evt_id"=>$evt_id);
    $query->execute($params);
    $res = $query->fetch();
    if($res['status']==00){
        $query = $conn->prepare("UPDATE `events` SET status = :state WHERE evt_id= :evt_id");
        $params = array(":state"=>01, ":evt_id"=>$evt_id);
        $query->execute($params);
    }
    else{
        $query = $conn->prepare("UPDATE `events` SET status = :state WHERE evt_id= :evt_id");
        $params = array(":state"=>00, ":evt_id"=>$evt_id);
        $query->execute($params);
    }


}
DisplayTasks();
if(isset($_POST['display'])){
    DisplayTasks();
}
if(isset($_POST['createButton'])){
    echo "create";
    CreateTask();
}

if(isset($_POST['modifyButton'])){
    ModifyTask();
}

if(isset($_POST['deleteButton'])){
    DeleteTask();
}

if(isset($_POST['stateButton'])){
    TaskStatus();
}
?>