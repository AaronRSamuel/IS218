<?php
$dbuser = "as3655";
$dbpass = "password";
$dbhost = "sql1.njit.edu";
$dbdatabase = "as3655";
?>
