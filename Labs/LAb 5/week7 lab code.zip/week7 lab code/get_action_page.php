<?php
echo "we are in get_action_page.php<br>";

if(isset($_GET["firstname"])){
	echo $_GET["firstname"].'<br>';
} 

if(isset($_GET["lastname"])) {
	echo "hello";
	echo $_GET["lastname"].'<br>';
} 

if (isset($_GET["password"])){
    echo $_GET["password"].'<br>';
}

//write the filter_input version for the text input.


//get values from radio
if (isset($_GET["gender"])){// determine if the value $_GET["gender"] is defined or not.
	
echo "The Gender is ".$_GET['gender'].'<br>';
$gender = $_GET['gender'];
echo "The gender is $gender<br>";}

//write filter_input version for the radio.

//write filter_input version for the drop-down list.

?>